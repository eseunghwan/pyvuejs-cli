# -*- coding: utf-8 -*-

pages = {
    "app": {
        "entry": "src/app/main.py",
        "vue": "src/app/index.vue", 
        "url": "/app",
        "title": "app!"
    }
}

server = {
}
