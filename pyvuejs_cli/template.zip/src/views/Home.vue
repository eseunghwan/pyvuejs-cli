<template>
    <div>
        <img alt="Vue logo" src="assets/logo.png">
        <HelloWorld msg="Welcome to Your Vue.js App"/>
    </div>
</template>

<script lang="python">
class Component:
    def __init__(self):
        pass
</script>
